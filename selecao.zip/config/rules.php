<?php

return [
    'header_link' => ['required', 'array'],
    'footer_link' => ['required', 'array']
];
