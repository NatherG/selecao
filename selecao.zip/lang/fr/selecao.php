<?php

return [
    "portfolio"     => [
        "title"     => "Articles",
        "subtitle"  => "Bonne lecture !",
    ],
    "footer" => [
        "nather"    => 'Créer par <a href="https://discord.gg/AhhAmnN">Nather_</a>'
    ],
    "config" => [
        "facebook"  => "facebook",
        "twitter"   => "Twitter",
        "discord"   => "Discord",
        "skype"     => "Skype",
        "teamspeak" => "Teamspeak",
        "instagram" => "Instagram",
        "active"    => "Activé",
        "desactive" => "Désactivé",
        "home"      => [
            "title" => "Titre",
            "subtitle" => "Description",
        ]
    ]
];
